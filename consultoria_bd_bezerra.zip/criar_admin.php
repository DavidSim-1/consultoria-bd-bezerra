<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
$total = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE tipo = 'admin'")->fetchColumn();
$erro = '';
$sucesso = false;
if ($total === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($senha) < 8) {
        $erro = 'Informe nome, e-mail válido e senha com pelo menos 8 caracteres.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, 'admin')");
        $stmt->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
        $sucesso = true;
    }
}
$titulo = 'Criar administrador';
require 'includes/header.php';
?>
<div class="formulario">
<?php if ($total > 0 || $sucesso): ?>
    <h1>Configuração concluída</h1>
    <p>Uma conta administrativa já existe ou foi criada com sucesso.</p>
    <div class="alerta sucesso">Por segurança, apague agora o arquivo <strong>criar_admin.php</strong> da pasta do projeto.</div>
    <a class="botao" href="login.php">Ir para o login</a>
<?php else: ?>
    <h1>Criar primeiro administrador</h1>
    <p>Use esta página apenas na configuração inicial. Após criar a conta, remova este arquivo.</p>
    <?php if ($erro): ?><div class="alerta"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
    <form method="post">
        <label>Nome</label><input name="nome" required maxlength="100">
        <label>E-mail</label><input type="email" name="email" required maxlength="150">
        <label>Senha (mínimo de 8 caracteres)</label><input type="password" name="senha" required minlength="8">
        <button class="botao" type="submit">Criar administrador</button>
    </form>
<?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>
